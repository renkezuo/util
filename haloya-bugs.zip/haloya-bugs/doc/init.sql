create table sys_user (
      user_id integer primary requestKey autoincrement ,
      user_name varchar(32) not null,
      nick_name varchar(32),
      login_pwd varchar(32) not null,
      user_type integer,
      phone varchar(11),
      avatar varchar(128),
      created_by varchar(32) default 'admin',
      created_time datetime ,
      updated_by varchar(32) default 'admin',
      updated_time datetime ,
      delete_flag integer default 0
);
insert into sys_user(user_name, nick_name,login_pwd,user_type,phone,created_time,updated_time)
values('admin','admin','admin_123',1,'15657126569',datetime(), datetime());

create table sys_role (
      role_id integer primary requestKey autoincrement ,
      role_name varchar(32) not null,
      tenant_id integer default 0,
      created_by varchar(32) default 'admin',
      created_time datetime ,
      updated_by varchar(32) default 'admin',
      updated_time datetime ,
      delete_flag integer default 0
);
insert into sys_role(role_name,tenant_id,created_time,updated_time) values('admin','0',datetime(), datetime());
create table sys_resource(
     res_id integer primary requestKey autoincrement ,
     parent_id integer not null,
     res_type integer not null,
     res_code varchar(32) not null,
     res_name varchar(32) not null,
     res_url varchar(128) not null,
     res_api varchar(256) not null,
     created_by varchar(32) default 'admin',
     created_time datetime ,
     updated_by varchar(32) default 'admin',
     updated_time datetime ,
     delete_flag integer default 0
);

create table sys_role_resource(
     role_id integer primary requestKey autoincrement,
     res_id integer not null
);