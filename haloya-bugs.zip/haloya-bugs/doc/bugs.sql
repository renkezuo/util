
create table biz_bug
(
    bug_id        integer primary key autoincrement,
    bug_no        varchar(16),
    bug_domain        varchar(16),
    bug_group         varchar(16),
    bug_sub_group      varchar(32),
    owner_space    varchar(32),
    created_user   varchar(32),
    developer     varchar(32),
    created_date   date,
    created_month  varchar(6),
    bug_degree     integer,
    red_line       integer,
    online_bug     integer,
    root_cause_type varchar(32),
    root_cause_desc varchar(512),
    bug_status     varchar(32),
    bug_title      varchar(128),
    reopen_times     integer,
    reject_times     integer,
    dev_duration     integer,
    test_duration     integer
);