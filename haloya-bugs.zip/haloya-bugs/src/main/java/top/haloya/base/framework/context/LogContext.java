package top.haloya.base.framework.context;


import top.haloya.base.framework.model.SysOperLog;

public class LogContext extends RequestContext<SysOperLog> {

    public static final void setLog(SysOperLog sysLog) {
        set(sysLog);
    }

    public static final SysOperLog getLog() {
        return get(SysOperLog.class);
    }
}
