package top.haloya.base.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class SpringUtils implements ApplicationContextAware{

    private static ApplicationContext CONTEXT = null;

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
        CONTEXT = applicationContext;
    }

    /**
     * 通过BeanID获取Bean
     *
     * @param name
     * @param <T>
     * @return
     */
    public static <T> T getBean(String name, Class<T> clazz) {
        return CONTEXT.getBean(name, clazz);
    }

    /**
     * 通过Bean类型获取Bean
     *
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T getBean(Class<T> clazz) {
        return CONTEXT.getBean(clazz);
    }

    /**
     * 通过接口类型获取所有实现类的MAP
     *
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> Map<String, T> getBeanMap(Class<T> clazz) {
        return CONTEXT.getBeansOfType(clazz);
    }

    public static ApplicationContext getContext() {
        return CONTEXT;
    }
}