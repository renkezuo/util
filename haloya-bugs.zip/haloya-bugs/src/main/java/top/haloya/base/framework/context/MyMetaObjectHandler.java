package top.haloya.base.framework.context;

import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;
import top.haloya.base.framework.model.UserInfo;
import top.haloya.base.utils.DateUtils;

import java.util.Date;
import java.util.Objects;

@Slf4j
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {

    @Override
    public void insertFill(MetaObject metaObject) {
        log.info("开始插入填充...");
        String userName = "";
        UserInfo userInfo = UserContext.getUserInfo() == null ? new UserInfo() : UserContext.getUserInfo();
        if (Objects.nonNull(userInfo)) {
            userName = userInfo.getUserName() == null ? "" : userInfo.getUserName();
        }
        this.strictInsertFill(metaObject, "createdTime", String.class, DateUtils.toStr(new Date()));
        this.strictInsertFill(metaObject, "createdBy", String.class, userName);
    }

    @Override
    public void updateFill(MetaObject metaObject) {
        log.info("开始更新填充...");
        String userName = "";
        UserInfo userInfo = UserContext.getUserInfo() == null ? new UserInfo() : UserContext.getUserInfo();
        if (Objects.nonNull(userInfo)) {
            userName = userInfo.getUserName() == null ? "" : userInfo.getUserName();
        }
        this.strictUpdateFill(metaObject, "updatedTime", String.class, DateUtils.toStr(new Date()));
        this.strictUpdateFill(metaObject, "updatedBy", String.class, userName);
    }
}
