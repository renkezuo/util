package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestKey {
    private String key;
}
