package top.haloya.base.framework;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.PathMatcher;
import org.springframework.util.StringUtils;
import top.haloya.base.framework.context.UserContext;
import top.haloya.base.framework.model.ApiStatus;
import top.haloya.base.framework.model.Role;
import top.haloya.base.framework.model.UserInfo;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * 对访问请求拦截处理
 */
@Slf4j
@AllArgsConstructor
public class AuthUserFilter implements Filter {

    private String whitelists;
    private String commonApis;

    public boolean authCheck(HttpServletRequest request, HttpServletResponse response) {
        String authToken = request.getHeader(SystemCst.AUTH);
        // 检查用户是否登录
        UserInfo userInfo = takeUserInfo(authToken);
        if (request.getRequestURI().startsWith("/unAuth")) {
            return true;
        }
        //白名单请求直接放行
        PathMatcher writeMatcher = new AntPathMatcher();
        String[] whiteListConfigUrls = whitelists.split(",");
        for (String path : whiteListConfigUrls) {
            if (writeMatcher.match(path, request.getRequestURI())) {
                return true;
            }
        }
        // 用户信息不正确，则返回非法访问
        if(Objects.isNull(userInfo) || Objects.isNull(userInfo.getCurrentRole())) {
            responseError(response);
            return false;
        }
        // 如果是超级管理员，直接返回
//        if(RoleEnum.SUPER_ADMIN.getKey().equals(userInfo.getCurrentRoleDTO().getRoleKey())) {
//            return true;
//        }
        // 白名单请求直接放行
        PathMatcher commonMatcher = new AntPathMatcher();
        String[] commonUrls = commonApis.split(",");
        for (String path : commonUrls) {
            if (commonMatcher.match(path, request.getRequestURI())){
                return true;
            }
        }
        // 获取用户鉴权信息,校验用户的菜单权限
//        HashSet<String> apiList = RedisUtils.get(RedisCst.LOGIN_USER_API_PERMISSIONS_KEY + userInfo.getCurrentRoleDTO().getRoleId(), HashSet.class);
//        String requestURI = request.getRequestURI();
//        if (CollectionUtil.isNotEmpty(apiList) && apiList.contains(requestURI)) {
//            return true;
//        }
//        ServletUtils.responseException(ApiCode.NOT_PERMISSION);
        return true;
    }

    private static void responseError(HttpServletResponse response){
        try {
            response.setStatus(ApiStatus.UNAUTHORIZED.getStatus());
            response.setContentType("application/json");
            response.setCharacterEncoding("utf-8");
            response.getWriter().print(ApiStatus.UNAUTHORIZED.getMessage());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private UserInfo takeUserInfo(String authToken) {
//        if(StringUtils.isEmpty(authToken)) {
//            return null;
//        }
//        String userId = RedisUtils.getStr(RedisCst.TOKEN_KEY + authToken);
//        if(StringUtils.isEmpty(userId)) {
//            return null;
//        }
//        try {
//            // 重置authToken对应的Redis键的过期时间
//            RedisUtils.expire(SystemCst.REDIS_TOKEN + authToken, 60*60L, TimeUnit.SECONDS);
//            UserInfo userInfo = RedisUtils.get(SystemCst.REDIS_USER + userId, UserInfo.class);
//            UserContext.setUserInfo(userInfo);
//            return userInfo;
//        } catch (Exception e) {
//            log.error("获取用户信息异常... {}", authToken);
//        }
        UserInfo userInfo = new UserInfo();
        userInfo.setCurrentRole(new Role());
        return userInfo;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        Filter.super.init(filterConfig);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        boolean authCheck = authCheck((HttpServletRequest) request, (HttpServletResponse) response);
        if(authCheck) {
            chain.doFilter(request,response);
        }
    }

    @Override
    public void destroy() {
        Filter.super.destroy();
    }
}
