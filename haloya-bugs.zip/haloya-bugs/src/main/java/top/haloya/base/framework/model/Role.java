package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Role  {

    /**
     *
     */
    private Long roleId;

    /**
     * 角色名称
     */
    private String roleName;

    /**
     * 角色权限字符串
     */
    private String roleKey;

    /**
     * 角色编码
     */
    private String roleCode;


}
