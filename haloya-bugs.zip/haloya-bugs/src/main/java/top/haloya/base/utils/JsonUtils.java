package top.haloya.base.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.databind.ser.std.ToStringSerializer;
import com.fasterxml.jackson.databind.type.CollectionType;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import top.haloya.base.framework.SystemCst;
import top.haloya.base.framework.config.JacksonConfig;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class JsonUtils {

    private static final ObjectMapper smallObjectMapper = smallObjectMapper();

    // 将对象转换为JSON字符串
    public static String toJson(Object obj) {
        if(Objects.isNull(obj)) {
            return null;
        }
        try {
            return smallObjectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("json转换失败", e);
            return null;
        }
    }

    /**
     * 可以通用于 Entity/DTO/List/Map/Set
     * @param json
     * @param clazz
     * @return
     * @param <T>
     */
    public static <T> T toObject(String json, Class<T> clazz) {
        if(StringUtils.isBlank(json)) {
            return null;
        }
        try {
            return smallObjectMapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            log.error("json转换失败", e);
            return null;
        }
    }

    public static <T> List<T> toList(String json, Class<T> clazz) {
        if(StringUtils.isBlank(json)) {
            return new ArrayList<>();
        }
        try {
            CollectionType listType = smallObjectMapper.getTypeFactory().constructCollectionType(ArrayList.class, clazz);
            return smallObjectMapper.readValue(json, listType);
        } catch (JsonProcessingException e) {
            log.error("json转换失败", e);
            return null;
        }
    }

    public static List<Map<String, Object>> toList(String json) {
        if(StringUtils.isBlank(json)) {
            return new ArrayList<>();
        }
        try {
            return smallObjectMapper.readValue(json, new TypeReference<List<Map<String, Object>>>() {});
        } catch (JsonProcessingException e) {
            log.error("json转换失败", e);
            return null;
        }
    }


    public static Map<String, Object> toMap(String json) {
        if(StringUtils.isBlank(json)) {
            return new HashMap<>();
        }
        try {
            return smallObjectMapper.readValue(json, new TypeReference<Map<String, Object>>() {});
        } catch (JsonProcessingException e) {
            log.error("json转换失败", e);
            return null;
        }
    }


    public static ObjectMapper initObjectMapper() {
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        // 设置日期格式
        SimpleDateFormat dateFormat = new SimpleDateFormat(SystemCst.YYYY_MM_DD_HH_MM_SS);
        objectMapper.setDateFormat(dateFormat);
        // 注册自定义序列化器
        JavaTimeModule javaTimeModule = new JavaTimeModule();
        javaTimeModule.addSerializer(LocalDateTime.class, LocalDateTimeSerializer.instance);
        javaTimeModule.addDeserializer(LocalDateTime.class, LocalDateTimeDeserializer.instance);
        objectMapper.registerModule(javaTimeModule);
        return objectMapper;
    }

    public static ObjectMapper smallObjectMapper(){
        ObjectMapper objectMapper = initObjectMapper();
        objectMapper.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        return objectMapper;
    }

    public static ObjectMapper webObjectMapper(){
        ObjectMapper objectMapper = initObjectMapper();
        SimpleModule module = new SimpleModule();
        module.addSerializer(Long.class, ToStringSerializer.instance);
        module.addSerializer(long.class, ToStringSerializer.instance);
        module.addSerializer(BigInteger.class, ToStringSerializer.instance);
        module.addSerializer(BigDecimal.class, ToStringSerializer.instance);
        objectMapper.registerModule(module);
        return objectMapper;
    }

    public static class LocalDateTimeSerializer extends JsonSerializer<LocalDateTime> {
        private static LocalDateTimeSerializer instance = new LocalDateTimeSerializer();
        @Override
        public void serialize(LocalDateTime value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            gen.writeString(value.format(DateTimeFormatter.ofPattern(SystemCst.YYYY_MM_DD_HH_MM_SS)));
        }
    }
    public static class LocalDateTimeDeserializer extends JsonDeserializer<LocalDateTime> {
        private static LocalDateTimeDeserializer instance = new LocalDateTimeDeserializer();
        @Override
        public LocalDateTime deserialize(JsonParser p, DeserializationContext dCtx) throws IOException, JacksonException {
            return LocalDateTime.parse(p.getText(), DateTimeFormatter.ofPattern(SystemCst.YYYY_MM_DD_HH_MM_SS));
        }
    }
}
