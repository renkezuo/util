package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class KV {
    private String key;
    private Object value;
}
