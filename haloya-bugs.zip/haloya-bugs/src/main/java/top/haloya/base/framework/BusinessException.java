package top.haloya.base.framework;

import org.springframework.http.HttpStatus;
import top.haloya.base.framework.model.ApiStatus;

/**
 * 业务异常
 *
 * @author zhusupeng
 */
public final class BusinessException extends RuntimeException {
    private static final long serialVersionUID = 1L;

    /**
     * 错误提示
     */
    private String message;

    private int status;

    /**
     * 空构造方法，避免反序列化问题
     */
    public BusinessException(Exception e) {
        this.message = e.getMessage();
        this.status = ApiStatus.BUSINESS_EXCEPTION.getStatus();
    }

    public BusinessException(String message) {
        this.message = message;
        this.status = ApiStatus.BUSINESS_EXCEPTION.getStatus();
    }

    public BusinessException(String message, int status) {
        this.message = message;
        this.status = status;
    }

    public BusinessException(String message, HttpStatus status) {
        this.message = message;
        this.status = status.value();
    }

    public BusinessException(ApiStatus apiStatus) {
        this.message = apiStatus.getMessage();
        this.status = apiStatus.getStatus();
    }

    @Override
    public String getMessage() {
        return message;
    }

    public BusinessException setMessage(String message) {
        this.message = message;
        return this;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
