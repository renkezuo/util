package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class BaseEntity {
    private String createdBy;
    private String updatedBy;
    private String createdTime;
    private String updatedTime;
    private Integer deleteFlag;
}
