package top.haloya.base.framework.model;

import lombok.Data;

import java.util.List;

/**
 * 用户基本信息
 */
@Data
public class UserInfo {

    /**
     * 用户id
     */
    private Long userId;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 用户类型（1:系统用户 2:注册用户）
     */
    private Integer userType;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 联系方式
     */
    private String phone;

    /**
     * 头像地址
     */
    private String avatar;

    /**
     * 当前角色信息
     */
    private Role currentRole;
}
