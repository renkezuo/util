package top.haloya.base.utils;

import cn.hutool.core.collection.CollUtil;
import cn.hutool.core.collection.ListUtil;

import java.util.Collection;
import java.util.List;

public class CollectionUtils {
    public static <T> boolean isEmpty(Collection<T> collection){
        return CollUtil.isEmpty(collection);
    }
    public static <T> boolean isNotEmpty(Collection<T> collection){
        return CollUtil.isNotEmpty(collection);
    }
    public static <T> List<T> emptyList(){
        return ListUtil.empty();
    }
}
