package top.haloya.base.utils;

import cn.hutool.core.util.StrUtil;

import java.util.Objects;

public class StringUtils {

    public static boolean isEmpty(String str){
        return StrUtil.isEmpty(str);
    }

    public static boolean isNotEmpty(String str){
        return StrUtil.isNotEmpty(str);
    }

    public static boolean isBlank(String str){
        return StrUtil.isBlank(str);
    }

    public static boolean isNotBlank(String str){
        return StrUtil.isNotBlank(str);
    }

    public static String orElse(Object value, String defaultValue) {
        if(Objects.isNull(value)) {
            return defaultValue;
        }
        return value.toString();
    }
    public static String orElseEmpty(Object value) {
        return orElse(value, "");
    }
    public static String substring(String str, int begin, int end){
        if(isBlank(str) || str.length() < end) {
            return str;
        }
        return str.substring(begin, end);
    }

    public static String join(String[] strs, String split) {
        String result = "";
        for(String str : strs) {
            result +=  split + str;
        }
        if(isNotBlank(result)) {
            return result.substring(1);
        }
        return result;
    }
}
