package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
public class ApiResult<T> {
    private int code = ApiStatus.SUCCESS.getStatus();
    private String msg = ApiStatus.SUCCESS.getMessage();
    private boolean success = true;
    private T data;
    public static ApiResult<String> ok(){
        return ok(null);
    }

    public static <T> ApiResult<T> ok(T data){
        return ok(data, ApiStatus.SUCCESS.getMessage());
    }

    public static <T> ApiResult<T> ok(T data, String message){
        return new ApiResult<T>()
                .setMsg(message)
                .setData(data);
    }

    public static ApiResult<String> fail(ApiStatus apiStatus){
        return new ApiResult<String>()
                .setSuccess(false)
                .setCode(apiStatus.getStatus())
                .setMsg(apiStatus.getMessage());
    }

    public static ApiResult<String> fail(String message){
        return new ApiResult<String>()
                .setSuccess(false)
                .setCode(500)
                .setMsg(message);
    }


    public static ApiResult<String> fail(Integer errorCode, String message){
        return new ApiResult<String>()
                .setSuccess(false)
                .setCode(errorCode)
                .setMsg(message);
    }

}
