package top.haloya.base.framework.context;


import top.haloya.base.framework.model.Role;
import top.haloya.base.framework.model.UserInfo;

import java.util.Objects;

public class UserContext extends RequestContext<UserInfo>{

    public static void setUserInfo(UserInfo userInfo){
        set(userInfo);
    }
    public static UserInfo getUserInfo(){
        return get(UserInfo.class);
    }
    public static String getCurrentUserName(){
        UserInfo userInfo = getUserInfo();
        if(Objects.isNull(userInfo)) {
            return null;
        }
        return userInfo.getUserName();
    }
    public static Long getCurrentUserId(){
        UserInfo userInfo = getUserInfo();
        if(Objects.isNull(userInfo)) {
            return null;
        }
        return userInfo.getUserId();
    }

    public static boolean checkAdmin(){
        UserInfo userInfo = getUserInfo();
        if(Objects.isNull(userInfo)) {
            return false;
        }
        Role currentRoleDTO = userInfo.getCurrentRole();
        if (Objects.isNull(currentRoleDTO)) {
            return false;
        }
       return true;
    }
}
