package top.haloya.base.framework.model;

public enum ApiStatus {

    /**
     * 操作成功
     **/
    SUCCESS(200, "操作成功"),
    /**
     * 非法访问
     **/
    UNAUTHORIZED(401, "非法访问"),
    /**
     * 没有权限
     **/
    NOT_PERMISSION(403, "没有权限"),
    /**
     * 你请求的资源不存在
     **/
    NOT_FOUND(404, "你请求的资源不存在"),
    /**
     * 操作失败
     **/
    FAIL(500, "操作失败"),
    /**
     * 系统异常
     **/
    SYSTEM_EXCEPTION(500, "系统异常"),
    /**
     * 系统异常
     **/
    DB_EXCEPTION(500, "数据库异常"),
    /**
     * 业务处理异常
     **/
    BUSINESS_EXCEPTION(500, "业务处理异常")
    ;

    private final int status;
    private final String message;

    ApiStatus(final int status, final String message) {
        this.status = status;
        this.message = message;
    }
    public int getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }

}
