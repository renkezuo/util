package top.haloya.base.framework;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface MyLog {

    /**
     * 说明
     */
    String content() default "";

    /**
     * 业务编码(1001-1001-101)
     */
    String bizCode() default "1001-1001-001";

}
