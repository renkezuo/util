package top.haloya.base.framework.context;

import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import java.util.Objects;

public class RequestContext<T> {

    public static <T> void set(T t){
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if(Objects.isNull(attributes)){
            return ;
        }
        if(Objects.isNull(t)) {
            return ;
        }
        attributes.setAttribute(t.getClass().getName(), t, RequestAttributes.SCOPE_REQUEST);
    }
    public static <T> T get(Class t){
        RequestAttributes attributes = RequestContextHolder.getRequestAttributes();
        if(Objects.isNull(attributes)){
            return null;
        }
        Object obj = attributes.getAttribute(t.getName(), RequestAttributes.SCOPE_REQUEST);
        if(Objects.isNull(obj)){
            return null;
        }
        return (T)obj;
    }
}
