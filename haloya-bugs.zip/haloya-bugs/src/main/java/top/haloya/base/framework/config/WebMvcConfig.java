package top.haloya.base.framework.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import top.haloya.base.framework.AuthUserFilter;


@Configuration
public class WebMvcConfig implements WebMvcConfigurer {
    @Value("${auth.white.apis}")
    private String whiteApis;
    @Value("${auth.common.apis}")
    private String commonApis;
    /**
     * 拦截所有请求
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
    }

    @Bean
    public FilterRegistrationBean<AuthUserFilter> authUserFilter() {
        FilterRegistrationBean<AuthUserFilter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new AuthUserFilter(whiteApis, commonApis));
        registration.addUrlPatterns("/*");
        registration.setName("authUserFilter");
        registration.setOrder(1);
        return registration;
    }
}