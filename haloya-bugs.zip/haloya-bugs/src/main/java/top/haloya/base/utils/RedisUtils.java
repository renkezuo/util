//package top.haloya.base.utils;
//
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.data.redis.core.StringRedisTemplate;
//import org.springframework.data.redis.core.ValueOperations;
//
//import java.util.List;
//import java.util.Objects;
//import java.util.concurrent.TimeUnit;
//
//@Slf4j
//public class RedisUtils {
//    private static StringRedisTemplate stringRedisTemplate;
//
//    public static void setStringRedisTemplate(StringRedisTemplate stringRedisTemplate) {
//        if (RedisUtils.stringRedisTemplate != null) {
//            return;
//        }
//        RedisUtils.stringRedisTemplate = stringRedisTemplate;
//    }
//
//    public static void delete(String key) {
//        try{
//            stringRedisTemplate.delete(key);
//        }catch (Exception e) {
//            log.error("删除【{}】失败", key ,e);
//        }
//    }
//
//    public static <T> T get(String key, Class<T> clazz) {
//        String result = null;
//        try{
//            if (Objects.isNull(key)) {
//                return null;
//            }
//            result = stringRedisTemplate.opsForValue().get(key);
//            if(Objects.isNull(result)) {
//                return null;
//            }
//            return JsonUtils.toObject(result, clazz);
//        }catch (Exception e) {
//            log.error("获取【{}】 -> 【{}】失败", key, result, e);
//        }
//        return null;
//    }
//
//
//    public static String getStr(String key) {
//        try{
//            if (Objects.isNull(key)) {
//                return "";
//            }
//            return stringRedisTemplate.opsForValue().get(key);
//        }catch (Exception e) {
//            log.error("获取【{}】失败", key, e);
//        }
//        return "";
//    }
//
//    public static <T> void set(String key, T value) {
//        try{
//            if (Objects.isNull(value) || Objects.isNull(key)) {
//                return;
//            }
//            String val = convertToString(value);
//            stringRedisTemplate.opsForValue().set(key, val);
//        }catch (Exception e) {
//            log.error("设定【{}】 -> 【{}】失败", key, value, e);
//        }
//    }
//
//    /**
//     *
//     * @param key
//     * @param value
//     * @param expireSecond 超时时间
//     * @param <T>
//     */
//    public static <T> void set(String key, T value, Long expireSecond) {
//        try{
//            if (Objects.isNull(value) || Objects.isNull(key)) {
//                return;
//            }
//            String val = convertToString(value);
//            stringRedisTemplate.opsForValue().set(key, val, expireSecond, TimeUnit.SECONDS);
//        }catch (Exception e) {
//            log.error("设定【{}】 -> 【{}】失败", key, value, e);
//        }
//    }
//
//    private static <T> String convertToString(T value) {
//        String val = "";
//        if (value instanceof String) {
//            val = (String) value;
//        } else if(isBaseClassType(value)){
//            val = value.toString();
//        } else {
//            val = JsonUtils.toJson(value);
//        }
//        return val;
//    }
//
//
//    public static boolean isBaseClassType(Object value){
//        if (value instanceof Integer
//                || value instanceof Long
//                || value instanceof Double
//                || value instanceof Boolean
//                || value instanceof Character) {
//            return true;
//        }
//        return false;
//    }
//
//    public static <T> void hset(String key, String hashKey, T val) {
//
//        try{
//            if (Objects.isNull(key)) {
//                return ;
//            }
//            stringRedisTemplate.opsForHash().put(key,hashKey,val);
//        }catch (Exception e) {
//            log.error("获取【{}】 -> 【{}】失败", key, e);
//        }
//    }
//
//    public static void expire(String key, long time, TimeUnit unit) {
//        if (time > 0) {
//            stringRedisTemplate.expire(key, time, unit);
//        }
//    }
//
//    public static Long increment(String key, Long count) {
//
//        try{
//            if (Objects.isNull(key)) {
//                return null;
//            }
//            return stringRedisTemplate.opsForValue().increment(key,count);
//        }catch (Exception e) {
//            log.error("获取【{}】 -> 【{}】失败", key, e);
//        }
//        return null;
//    }
//
//    /**
//     * 批量获取 Redis 中的值。
//     *
//     * @param keys     需要获取的键的列表
//     * @return 包含值的列表
//     */
//    public static List<String> batchGetValues(List<String> keys) {
//        ValueOperations<String, String> opsForValue = stringRedisTemplate.opsForValue();
//        return opsForValue.multiGet(keys);
//    }
//}
