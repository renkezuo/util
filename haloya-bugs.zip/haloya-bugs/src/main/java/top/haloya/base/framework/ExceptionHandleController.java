package top.haloya.base.framework;

import lombok.extern.slf4j.Slf4j;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import top.haloya.base.framework.model.ApiResult;
import top.haloya.base.framework.model.ApiStatus;
import top.haloya.base.utils.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.sql.SQLException;
import java.util.List;
import java.util.Objects;

/**
 * 异常统一处理
 *
 * @author Linzhaoguan
 * @version V1.0
 * @date 2019年9月11日
 */
@Slf4j
@ControllerAdvice
public class ExceptionHandleController {

    @ResponseBody
    @ExceptionHandler(BusinessException.class)
    public ApiResult<String> handleServiceException(BusinessException e, HttpServletRequest request) {
        log.error(e.getMessage(), e);
        return ApiResult.fail(e.getStatus(), e.getMessage());
    }

    @ResponseBody
    @ExceptionHandler(BindException.class)
    public ApiResult<String> handleBindException(BindException ex,HttpServletRequest request) {
        log.error(ex.getMessage(), ex);
        try {
            // 拿到@NotNull,@NotBlank和 @NotEmpty等注解上的message值
            String msg = Objects.requireNonNull(ex.getBindingResult().getFieldError()).getDefaultMessage();
            if (StringUtils.isNotEmpty(msg)) {
                // 自定义状态返回
                return ApiResult.fail(ApiStatus.BUSINESS_EXCEPTION.getStatus(), msg);
            }
        } catch (Exception ignored) {
        }
        // 参数类型不匹配检验
        StringBuilder msg = new StringBuilder();
        List<FieldError> fieldErrors = ex.getFieldErrors();
        fieldErrors.forEach((oe) ->
                msg.append("参数:[").append(oe.getObjectName())
                        .append(".").append(oe.getField())
                        .append("]的传入值:[").append(oe.getRejectedValue()).append("]与预期的字段类型不匹配.")
        );
        return ApiResult.fail(msg.toString());
    }
    @ResponseBody
    @ExceptionHandler(SQLException.class)
    public ApiResult<String> handleException(SQLException e, HttpServletRequest request) {
        log.error("URI: {} 捕获异常: {}", request.getRequestURI(), e.getMessage(), e);
        return ApiResult.fail(ApiStatus.DB_EXCEPTION);
    }

    @ResponseBody
    @ExceptionHandler(RuntimeException.class)
    public ApiResult<String> handleException(RuntimeException e, HttpServletRequest request) {
        log.error("URI: {} 捕获异常: {}", request.getRequestURI(), e.getMessage(), e);
        return ApiResult.fail(ApiStatus.SYSTEM_EXCEPTION);
    }

    @ResponseBody
    @ExceptionHandler(Exception.class)
    public ApiResult<String> handleException(Exception e, HttpServletRequest request) {
        log.error("URI: {} 捕获异常: {}", request.getRequestURI(), e.getMessage(), e);
        return ApiResult.fail(ApiStatus.SYSTEM_EXCEPTION);
    }
}
