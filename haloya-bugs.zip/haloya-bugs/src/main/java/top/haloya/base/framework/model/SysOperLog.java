package top.haloya.base.framework.model;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * 操作日志记录表 oper_log
 *
 * @author
 */
@Getter
@Setter
public class SysOperLog {
    /**
     * 日志主键
     */
    private Long logId;

    /**
     * 操作描述
     */
    private String content;

    /**
     * 业务编码
     */
    private String bizCode;

    /**
     * 请求方法
     */
    private String method;

    /**
     * 请求方式
     */
    private String requestMethod;
    /**
     * 操作人员
     */
    private Long operUserId;

    /**
     * 操作人员
     */
    private String operName;

    /**
     * 请求url
     */
    private String requestUrl;

    /**
     * 操作地址
     */
    private String operIp;

    /**
     * 请求参数
     */
    private String requestParam;

    /**
     * 返回参数
     */
    private String responseResult;

    /**
     * 操作状态（0正常 1异常）
     */
    private Integer status;

    /**
     * 错误消息
     */
    private String errorMsg;

    /**
     * 操作时间
     */
    private LocalDateTime operTime;

    /**
     * 消耗时间
     */
    private Long costTime;

    /**
     * 结束时间
     */
    private LocalDateTime endTime;

}
