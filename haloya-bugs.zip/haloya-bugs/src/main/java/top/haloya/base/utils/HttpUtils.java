package top.haloya.base.utils;

import cn.hutool.http.Header;
import lombok.extern.slf4j.Slf4j;
import okhttp3.ConnectionPool;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.springframework.http.MediaType;
import top.haloya.base.framework.BusinessException;
import top.haloya.base.framework.model.KV;

import java.io.IOException;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Slf4j
public class HttpUtils {

    private final static OkHttpClient client = new OkHttpClient.Builder()
            .connectionPool(new ConnectionPool(10, 1, TimeUnit.MINUTES))
            .readTimeout(3, TimeUnit.SECONDS)
            .writeTimeout(3, TimeUnit.SECONDS)
            .build();

//    public static void main(String[] args) {
//        String html = get("https://ip.900cha.com/45.117.100.175.html");
//        log.info("{}", html);
//    }

    public static <T> T get(String url){
        Request request = getRequest(url, Collections.emptyList(), Collections.emptyList());
        return receiveHttp(url, null, request);
    }

    public static <T> T post(String url, String json) {
        Request request = postRequest(url, Collections.emptyList(), json);
        return receiveHttp(url, null, request);
    }

    public static <T> T get(String url, Class<T> clazz){
        Request request = getRequest(url, Collections.emptyList(), Collections.emptyList());
        return receiveHttp(url, clazz, request);
    }

    public static <T> T post(String url, String json, Class<T> clazz) {
        Request request = postRequest(url, Collections.emptyList(), json);
        return receiveHttp(url, clazz, request);
    }

    public static <T> T get(String url, List<KV> headers, List<KV> params, Class<T> clazz){
        Request request = getRequest(url, headers, params);
        return receiveHttp(url, clazz, request);
    }

    public static <T> T post(String url, List<KV> headers, String json, Class<T> clazz) {
        Request request = postRequest(url, headers, json);
        return receiveHttp(url, clazz, request);
    }

    private static <T> @Nullable T receiveHttp(String url, Class<T> clazz, Request request) {
        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                // 读取响应体内容
                String responseBody = "";
                if (Objects.nonNull(response.body())) {
                    responseBody = response.body().string();
                }

                // 记录日志，注意转义响应体以避免敏感信息泄露
                log.info("{}请求 {} ", request.method(), url);
                log.info("响应  {}", responseBody);
                if(Objects.isNull(clazz) || clazz == String.class) {
                    return (T) responseBody;
                }
                T t = JsonUtils.toObject(responseBody, clazz);
                return t;
            } else {
                // 如果请求失败，记录状态码
                log.info("调用远程api接口查询为空: {}", response.code());
                return null;
            }
        } catch (IOException e) {
            throw new BusinessException(e);
        }
    }

    public static Request getRequest(String url, List<KV> headers, List<KV> params) {

        url = addUrlParams(url, params);

        Request.Builder builder = new Request.Builder().url(url);
        // 添加头信息
        addHeaders(builder, headers);
        // 设置get请求
        builder.get();

        return builder.build();
    }

    public static Request postRequest(String url, List<KV> headers, String json) {
        Request.Builder builder = new Request.Builder().url(url);

        addHeaders(builder, headers);

        addJsonBody(json, builder);

        return builder.build();
    }

    public static Request postFormRequest(String url, List<KV> headers, List<KV> params) {
        Request.Builder builder = new Request.Builder().url(url);

        addHeaders(builder, headers);

        addFormBody(params, builder);

        return builder.build();
    }

    private static @NotNull String addUrlParams(String url, List<KV> params) {
        String urlParams = "";
        if (CollectionUtils.isNotEmpty(params)) {
            for (KV kv : params) {
                if(StringUtils.isBlank(kv.getKey())) {
                    continue;
                }
                urlParams += "&" + kv.getKey() + "=" + StringUtils.orElseEmpty(kv.getValue());
            }
            if(urlParams.length() > 1) {
                urlParams = "?" + urlParams.substring(1);
            }
        }
        url = url + urlParams;
        return url;
    }

    private static void addJsonBody(String json, Request.Builder builder) {
        if (StringUtils.isNotBlank(json)) {
            RequestBody body = RequestBody.create(okhttp3.MediaType.parse(MediaType.APPLICATION_JSON_VALUE), json);
            builder.post(body);
        }
    }

    private static void addHeaders(Request.Builder builder, List<KV> headers) {
        URL url = builder.getUrl$okhttp().url();
        builder.addHeader(Header.ACCEPT.getValue(), "*/*");
        builder.addHeader(Header.USER_AGENT.getValue(), "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36");
        builder.addHeader(Header.ACCEPT_LANGUAGE.getValue(), "zh-CN,zh;q=0.9,en;q=0.8");
        builder.addHeader(Header.REFERER.getValue(), url.getProtocol() + "://" + url.getHost());
        if (CollectionUtils.isNotEmpty(headers)) {
            for (KV kv : headers) {
                if(StringUtils.isBlank(kv.getKey())) {
                    continue;
                }
                builder.addHeader(kv.getKey(), StringUtils.orElseEmpty(kv.getValue()));
            }
        }
    }

    private static void addFormBody(List<KV> params, Request.Builder builder) {
        if (CollectionUtils.isNotEmpty(params)) {
            FormBody.Builder formBuild = new FormBody.Builder();
            for (KV kv : params) {
                if(StringUtils.isBlank(kv.getKey())) {
                    continue;
                }
                formBuild.add(kv.getKey(), StringUtils.orElseEmpty(kv.getValue()));
            }
            builder.post(formBuild.build());
        }
    }
}
