package top.haloya.base.framework;

public class SystemCst {
    public static final String AUTH = "h-auth";
    public static final String REDIS_TOKEN = "token:";
    public static final String REDIS_USER = "user:";
    public static final String H_LOG = "logId";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
}
