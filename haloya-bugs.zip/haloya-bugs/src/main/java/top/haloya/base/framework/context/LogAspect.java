package top.haloya.base.framework.context;

import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindingResult;
import org.springframework.web.multipart.MultipartFile;
import top.haloya.base.framework.MyLog;
import top.haloya.base.framework.model.SysOperLog;
import top.haloya.base.utils.JsonUtils;
import top.haloya.base.utils.NetUtils;
import top.haloya.base.utils.StringUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.lang.reflect.Method;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.Map;
import java.util.Objects;

/**
 * 操作日志记录处理
 *
 * @author ruoyi
 */
@Aspect
@Component
@Slf4j
public class LogAspect {

    @Pointcut("@annotation(top.haloya.base.framework.MyLog)")
    public void pointcut(){
        log.info("pointcut");
    }

    /**
     * 处理请求前执行
     */
    @Before(value = "pointcut()")
    public void doBefore(JoinPoint joinPoint) {
        log.info("before..");
        beginLog(joinPoint);
    }

    /**
     * 处理完请求后执行
     *
     * @param joinPoint 切点
     */
    @AfterReturning(pointcut = "pointcut()", returning = "jsonResult")
    public void doAfterReturning(JoinPoint joinPoint, Object jsonResult) {
        endLog(null, jsonResult);
    }

    /**
     * 拦截异常操作
     *
     * @param joinPoint 切点
     * @param e         异常
     */
    @AfterThrowing(value = "pointcut()", throwing = "e")
    public void doAfterThrowing(JoinPoint joinPoint, Exception e) {
        endLog(e, null);
    }

    private void beginLog(final JoinPoint joinPoint){
        try {
            // 初始化Log，包含操作时间，操作人，调用方法等
            SysOperLog operLog = initBaseLog(joinPoint);
            // 填充请求信息，比如IP，参数，url，method等
            fillRequestInfo(joinPoint, operLog);
            // 代理了RequestHolderContext，不需要释放
            LogContext.setLog(operLog);
            log.info("request logId: {}, url -> {}, method: {}, param: {}", operLog.getLogId(), operLog.getRequestUrl(), operLog.getMethod(), operLog.getRequestParam());
        } catch (Exception exp) {
            // 记录本地异常日志
            log.error("异常信息:", exp);
        }
    }

    private SysOperLog initBaseLog(JoinPoint joinPoint) {
        SysOperLog operLog = LogContext.getLog();
        if(Objects.isNull(operLog)){
            operLog = new SysOperLog();
            operLog.setLogId(NetUtils.takeLogId());
        }
        operLog.setStatus(200);
        String username = UserContext.getCurrentUserName();
        if (StringUtils.isNotBlank(username)) {
            operLog.setOperUserId(UserContext.getCurrentUserId());
            operLog.setOperName(username);
        }
        // 设置方法名称
        String className = joinPoint.getTarget().getClass().getName();
        MethodSignature methodSignature = (MethodSignature)joinPoint.getSignature();
        Method method = methodSignature.getMethod();
        MyLog myLog = method.getAnnotation(MyLog.class);
        String methodName = method.getName();

        operLog.setMethod(className + "." + methodName + "()");
        operLog.setOperTime(LocalDateTime.now());
        if(Objects.nonNull(myLog)){
            // 填充Log请求信息
            operLog.setBizCode(myLog.bizCode());
            operLog.setContent(myLog.content());
        }
        return operLog;
    }

    protected void endLog(final Exception e, Object jsonResult) {
        try {
            // *========数据库日志=========*//
            SysOperLog operLog = LogContext.getLog();
            if (e != null) {
                operLog.setStatus(500);
                operLog.setErrorMsg(StringUtils.substring(e.getMessage(), 0, 2000));
            }
            // 设置消耗时间
            LocalDateTime now = LocalDateTime.now();
            Duration duration = Duration.between(operLog.getOperTime(), now);
            operLog.setCostTime(duration.toMillis());
            operLog.setEndTime(now);
            if(Objects.nonNull(jsonResult)){
                operLog.setResponseResult(StringUtils.substring(JsonUtils.toJson(jsonResult), 0, 2000));
            }
            // 保存数据库
            log.info("response logId {}, time: {}, param: {}", operLog.getLogId(), operLog.getCostTime(), operLog.getResponseResult());
        } catch (Exception exp) {
            // 记录本地异常日志
            log.error("异常信息: ", exp);
        }
    }
    /**
     * 获取请求的参数，放到log中
     *
     * @param operLog 操作日志
     * @throws Exception 异常
     */
    private void fillRequestInfo(JoinPoint joinPoint, SysOperLog operLog) throws Exception {
        String ip = NetUtils.getIpAddr();
        operLog.setOperIp(ip);
        HttpServletRequest request = NetUtils.getRequest();
        if(Objects.isNull(request)) {
            return ;
        }
        String requestMethod = request.getMethod();
        operLog.setRequestUrl(StringUtils.substring(request.getRequestURI(), 0, 255));
        operLog.setRequestMethod(requestMethod);
        Map<String, String> paramsMap = NetUtils.getParamMap();
        if (paramsMap.isEmpty() && checkPostAndPut(requestMethod)) {
            String params = argsArrayToString(joinPoint.getArgs());
            operLog.setRequestParam(StringUtils.substring(params, 0, 2000));
        } else {
            operLog.setRequestParam(StringUtils.substring(JsonUtils.toJson(paramsMap), 0, 2000));
        }
    }

    private static boolean checkPostAndPut(String requestMethod) {
        return HttpMethod.PUT.name().equals(requestMethod)
                || HttpMethod.POST.name().equals(requestMethod);
    }

    /**
     * 参数拼装
     */
    private String argsArrayToString(Object[] paramsArray) {
        String params = "";
        if (Objects.isNull(paramsArray) || paramsArray.length == 0) {
            return params;
        }
        for (Object o : paramsArray) {
            if (Objects.isNull(o) || isFilterObject(o)) {
                continue;
            }
            try {
                String jsonObj = JsonUtils.toJson(o);
                params += jsonObj.toString() + " ";
            } catch (Exception e) {
            }
        }
        return params.trim();
    }

    /**
     * 判断是否需要过滤的对象。
     * 过滤非序列化对象
     * @param o 对象信息。
     * @return 如果是需要过滤的对象，则返回true；否则返回false。
     */
    @SuppressWarnings("rawtypes")
    public boolean isFilterObject(final Object o) {
        Class<?> clazz = o.getClass();
        if (clazz.isArray()) {
            return clazz.getComponentType().isAssignableFrom(MultipartFile.class);
        } else if (Collection.class.isAssignableFrom(clazz)) {
            Collection collection = (Collection) o;
            for (Object value : collection) {
                return value instanceof MultipartFile;
            }
        } else if (Map.class.isAssignableFrom(clazz)) {
            Map map = (Map) o;
            for (Object value : map.entrySet()) {
                Map.Entry entry = (Map.Entry) value;
                return entry.getValue() instanceof MultipartFile;
            }
        }
        return o instanceof MultipartFile || o instanceof HttpServletRequest
                || o instanceof HttpServletResponse || o instanceof BindingResult;
    }
}
