package top.haloya.www.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.haloya.www.model.entity.UserEntity;

public interface UserMapper extends BaseMapper<UserEntity> {
}
