package top.haloya.www.model.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import top.haloya.base.framework.model.BaseEntity;

@Setter
@Getter
@TableName("sys_user")
public class UserEntity extends BaseEntity {
    /**
     * 用户id
     */
    @TableId
    private Integer userId;

    /**
     * 用户名
     */
    private String userName;
    /**
     * 密码
     */
    private String loginPwd;

    /**
     * 用户类型（1:系统用户 2:注册用户）
     */
    private Integer userType;
    /**
     * 昵称
     */
    private String nickName;
    /**
     * 联系方式
     */
    private String phone;
    /**
     * 头像地址
     */
    private String avatar;

}
