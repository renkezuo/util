package top.haloya.www.model.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Setter
@Getter
@Accessors(chain = true)
public class IpAddress {
    private String ip;
    private String country;
    private String province;
    private String city;
    private String adcode;

    public static IpAddress build(){
        return new IpAddress();
    }
}
