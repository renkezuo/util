package top.haloya.www.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import top.haloya.base.framework.MyLog;
import top.haloya.base.framework.model.ApiResult;
import top.haloya.base.framework.model.ApiStatus;
import top.haloya.base.framework.BaseController;
import top.haloya.base.framework.BusinessException;
import top.haloya.base.framework.model.RequestKey;
import top.haloya.base.utils.NetUtils;
import top.haloya.www.model.dto.IpAddress;
import top.haloya.www.service.IpService;

import javax.annotation.Resource;
import java.util.Objects;

@RestController
@RequestMapping("ip")
@Slf4j
public class IpController extends BaseController {
    @Resource
    IpService ipService;

    @PostMapping("/show")
    @ResponseBody
    @MyLog
    public ApiResult<IpAddress> show(@RequestBody(required = false) RequestKey requestKey) {
        String ip = null;
        if (Objects.nonNull(requestKey)) {
            ip = requestKey.getKey();
        }
        if (Objects.isNull(ip)) {
            ip = NetUtils.getIpAddr();
        }
        if (Objects.isNull(ip)) {
            throw new BusinessException(ApiStatus.BUSINESS_EXCEPTION);
        }
        IpAddress ipAddress = ipService.getIp(ip);
        return ApiResult.ok(ipAddress);
    }
}
