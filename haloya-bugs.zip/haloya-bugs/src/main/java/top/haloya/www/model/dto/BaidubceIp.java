package top.haloya.www.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Setter
@Getter
public class BaidubceIp {
    private String continent;
    private String country;
    private String zipcode;
    private String timezone;
    private String accuracy;
    private String owner;
    private String isp;
    private String source;
    private String areacode;
    private String adcode;
    private Integer asnumber;
    private String lat;
    private String lng;
    private String radius;
    private String prov;
    private String city;
    private String district;
    private LocalDateTime time;
}