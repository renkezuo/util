package top.haloya.www.service;

import lombok.AllArgsConstructor;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import top.haloya.www.ThirdApiUtils;
import top.haloya.www.mapper.UserMapper;
import top.haloya.www.model.dto.BaidubceIp;
import top.haloya.www.model.dto.IpAddress;

import java.util.Objects;

@Service
@AllArgsConstructor
public class IpService {
    private final UserMapper userMapper;
    @Cacheable(cacheNames = "ips", key = "#ip")
    public IpAddress getIp(String ip){
        BaidubceIp apiResult =  ThirdApiUtils.baidubceIp(ip);
        IpAddress ipAddress = IpAddress.build();
        if(Objects.isNull(apiResult)) {
            ipAddress =  ThirdApiUtils.gaodeIp(ip);
        } else {
            ipAddress.setIp(ip)
                    .setCity(apiResult.getCity()).setAdcode(apiResult.getZipcode())
                    .setCountry(apiResult.getCountry()).setProvince(apiResult.getProv());
        }
//        if(Objects.isNull(ipAddress) || Objects.isNull(ipAddress.getCity())) {
//            return null;
//        }
        return ipAddress;
    }
}
