package top.haloya.www;

import top.haloya.base.utils.HttpUtils;
import top.haloya.www.model.dto.BaidubceIp;
import top.haloya.www.model.dto.BaidubceResp;
import top.haloya.www.model.dto.IpAddress;

import java.util.Objects;

public class ThirdApiUtils {
    final static String GAODE_KEY = "e257c5179b27e06747c32d70973f7fe3";
    final static String GAODE_API_IP = "https://restapi.amap.com/v3/ip?key=" + GAODE_KEY + "&ip=";
    final static String BAIDUBCE_API_IP = "https://qifu-api.baidubce.com/ip/geo/v1/district?ip=";
    final static String API_IP_1 = "https://ipshudi.com/";

    final static String GAODE = "gaode";
    final static String CHAIP = "chaIp";
    final static String BAIDUBCE = "baidubce";

    public static IpAddress gaodeIp(String ip) {
        return HttpUtils.get(GAODE_API_IP + ip, IpAddress.class);
    }

    public static BaidubceIp baidubceIp(String ip){
        BaidubceResp resp =  HttpUtils.get(BAIDUBCE_API_IP + ip, BaidubceResp.class);
        if(Objects.isNull(resp) || Objects.isNull(resp.getData())) {
            return null;
        }
        return resp.getData();
    }

    public static String chaIp(String ip){
        String ipHtml = HttpUtils.get(API_IP_1 + ip + ".htm");
        return ipHtml;
    }

}
