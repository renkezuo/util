package top.haloya.bugs.model.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@EqualsAndHashCode
public class OnlineBug {
//    @ExcelProperty("指派给")
//    private String currentUser;
    @ExcelProperty("创建人")
    private String createdUser;
    @ExcelProperty("创建时间")
    private Date createdDate;
    @ExcelProperty("缺陷归属")
    private String developer;// 开发者
    @ExcelProperty("所属空间")
    private String ownerSpace;
    @ExcelProperty("严重程度")
    private String bugDegree;
    @ExcelProperty("质量红线")
    private String redLine;
    @ExcelProperty("根因类型")
    private String rootCauseType;
    @ExcelProperty("原因分析")
    private String rootCauseDesc;
    @ExcelProperty("状态")
    private String bugStatus;
    @ExcelProperty("主题")
    private String bugTitle;
    @ExcelProperty("编号")
    private String bugNo;

}