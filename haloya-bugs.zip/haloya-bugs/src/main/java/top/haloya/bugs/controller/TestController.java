package top.haloya.bugs.controller;

import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import top.haloya.base.utils.JsonUtils;
import top.haloya.bugs.mapper.BugMapper;
import top.haloya.www.mapper.UserMapper;

import javax.annotation.Resource;

@RestController
@RequestMapping("test")
@Slf4j
public class TestController {
    @Resource
    BugMapper bugMapper ;
    @Resource
    UserMapper userMapper ;
    @GetMapping("bug")
    public String getBug(){
        return JsonUtils.toJson(bugMapper.selectById(1));
    }
    @GetMapping("user")
    public String getUser(){
        return JsonUtils.toJson(userMapper.selectById(1));
    }
}
