package top.haloya.bugs.model.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@EqualsAndHashCode
public class TestBug extends OnlineBug{
    @ExcelProperty("重开次数")
    private String reopenTimes;
    @ExcelProperty("拒绝次数")
    private String rejectTimes;
    @ExcelProperty("开发解决周期")
    private String devDuration;
    @ExcelProperty("测试解决周期")
    private String testDuration;
}