package top.haloya.bugs.mapper;

import com.baomidou.dynamic.datasource.annotation.DS;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import top.haloya.bugs.model.entity.BugEntity;

@DS("bugs")
public interface BugMapper extends BaseMapper<BugEntity> {
}
