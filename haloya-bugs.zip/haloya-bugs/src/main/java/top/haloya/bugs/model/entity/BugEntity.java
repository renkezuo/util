package top.haloya.bugs.model.entity;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@TableName("biz_bug")
public class BugEntity {
    @TableId
    private Integer bugId;
    /**
     * 编号
     */
    private String bugNo;
    /**
     * 领域
      */
    private String bugDomain;
    /**
     * 分组
     */
    private String bugGroup;
    /**
     * 子分组
     */
    private String bugSubGroup;
    /**
     * 所属空间
     */
    private String ownerSpace;
    /**
     * 创建人
     */
    private String createdUser;
    /**
     * 开发者
     */
    private String developer;
    // 重开次数、拒绝次数、开发解决周期、测试验证周期
    /**
     * 创建时间
     */
    private String createdDate;
    /**
     * 创建月份
     */
    private String createdMonth;
    /**
     * 严重程度
     */
    private Integer bugDegree;
    /**
     * 是否红线
     */
    private Integer redLine;
    /**
     * 非线上 0
     * 线上  1
     */
    private Integer onlineBug;
    /**
     * 根本原因
     */
    private String rootCauseType;
    /**
     * 根本原因
     */
    private String rootCauseDesc;
    /**
     * 状态
     */
    private String bugStatus;
    /**
     * bug主题
     */
    private String bugTitle;
    /**
     * 重开次数
     */
    private Integer reopenTimes;
    /**
     * 拒绝次数
     */
    private Integer rejectTimes;
    /**
     * 开发解决时长
     */
    private Integer devDuration;
    /**
     * 测试验证时长
     */
    private Integer testDuration;
}
