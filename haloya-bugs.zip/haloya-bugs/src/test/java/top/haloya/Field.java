package top.haloya;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Field {
    private String type;
    private String name;
}
