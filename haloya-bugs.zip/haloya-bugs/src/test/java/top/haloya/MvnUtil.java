package top.haloya;

import lombok.extern.slf4j.Slf4j;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
public class MvnUtil {

    public static void main(String[] args) {
        String mavenHome = "C:" + File.separator + "mytool" + File.separator + "apache-maven-3.9.9";
        String command = mavenHome + "" + File.separator + "bin" + File.separator + "mvn.cmd dependency:list";
        String repository = "C:" + File.separator + "code" + File.separator + "repository2";
        String targetPath = "target" + File.separator + "lib";
        try {
            File targetLib = new File(targetPath);
            if(!targetLib.exists()) {
                targetLib.mkdirs();
            }
            Process process = Runtime.getRuntime().exec(command);
            InputStream inputStream = process.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(inputStream, "GBK"));
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                if (line.contains("-- module ")) {
                    String[] strs = line.split(":");
                    String packageDir = strs[0].split("INFO]")[1].trim().replace(".", File.separator);
                    File file = new File(repository + File.separator
                            + packageDir+File.separator
                            + strs[1] + File.separator
                            + strs[3] + File.separator
                            + strs[1] + "-"+ strs[3] + ".jar");
                    File target = new File(targetPath + File.separator + file.getName());
                    log.info("copy {} -> {}", file.getAbsolutePath(), target.getAbsolutePath());
                    Files.copy(file.toPath(), target.toPath());
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
