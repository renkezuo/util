package top.haloya;

import freemarker.ext.beans.BeansWrapper;
import freemarker.ext.beans.BeansWrapperBuilder;
import freemarker.template.Configuration;
import freemarker.template.ObjectWrapper;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import lombok.Getter;
import lombok.Setter;
import top.haloya.base.utils.JsonUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class JsonToDTO {
    public static Configuration config;
    public static Configuration getConfig() throws IOException {
        if(Objects.isNull(config)){
            Configuration configuration = new Configuration(Configuration.VERSION_2_3_32);
            configuration.setDirectoryForTemplateLoading(new File("src/test/resources"));
            configuration.setDefaultEncoding("UTF-8");
            config = configuration;
        }
        return config;
    }


    public static void main(String[] args) {
        String basePkg = "top.haloya.www.model.dto";
        String baseName = "BaidubceIp";
        String dirPath = pkgToPath(basePkg);
        File dir = new File(pkgToPath(basePkg));
        String json = "{\n" +
                "    \"code\": \"Success\",\n" +
                "    \"data\": {\n" +
                "        \"continent\": \"大洋洲\",\n" +
                "        \"country\": \"澳大利亚\",\n" +
                "        \"zipcode\": \"2000\",\n" +
                "        \"timezone\": \"UTC+10\",\n" +
                "        \"accuracy\": \"城市\",\n" +
                "        \"owner\": \"Passion Only Pty Ltd\",\n" +
                "        \"isp\": \"xTom Pty Ltd\",\n" +
                "        \"source\": \"数据挖掘\",\n" +
                "        \"areacode\": \"AU\",\n" +
                "        \"adcode\": \"\",\n" +
                "        \"asnumber\": 8888,\n" +
                "        \"lat\": \"-33.871675\",\n" +
                "        \"lng\": 151.211365,\n" +
                "        \"radius\": \"\",\n" +
                "        \"prov\": \"新南威尔士州\",\n" +
                "        \"city\": \"悉尼\",\n" +
                "        \"district\": \"\",\n" +
                "        \"time\": \"2024-09-05 13:19:00\"\n" +
                "    },\n" +
                "    \"charge\": false,\n" +
                "    \"msg\": \"查询成功\",\n" +
                "    \"ip\": \"45.117.100.175\",\n" +
                "    \"coordsys\": \"WGS84\"\n" +
                "}";
        if (!dir.exists()) {
            dir.mkdirs();
        }
        Map<String, Object> map = JsonUtils.toMap(json);
        generateDto(map, basePkg, baseName, dirPath);
    }

    private static void generateDto(Map<String, Object> map,
                                    String basePkg, String className, String dirPath) {
        String dateRegex = "^\\d{4}-\\d{2}-\\d{2}.*";
        try (Writer writer = new FileWriter(dirPath + File.separator + className + ".java")){
            Template template = getConfig().getTemplate("dto.ftl");
            Map<String, Object> data = new HashMap<>();
            List<Field> fields = new ArrayList<>();
            List<String> imports = new ArrayList<>();
            data.put("pkg", basePkg);
            data.put("className", className);
            data.put("fields", fields);
            data.put("imports", imports);
            // 创建第一个实体类
            for (Map.Entry<String, Object> item : map.entrySet()) {
                Field field = new Field();
                fields.add(field);
                String key = item.getKey();
                char first = Character.toUpperCase(key.charAt(0));
                String keyClassName = first + key.substring(1);
                field.setName(key);
                field.setType("String");
                if (Objects.isNull(item.getValue())) {
                    continue;
                }
                if (item.getValue() instanceof Map) {
                    Map<String,Object> subMap = (Map<String, Object>)item.getValue();
                    field.setType(keyClassName);
                    generateDto(subMap, basePkg, keyClassName, dirPath);
                } else if (item.getValue() instanceof Boolean){
                    field.setType("Boolean");
                } else if (item.getValue() instanceof Integer){
                    field.setType("Integer");
                } else if(item.getValue().toString().matches(dateRegex)){
                    field.setType("LocalDateTime");
                    if(!imports.contains("java.time.LocalDateTime")) {
                        imports.add("java.time.LocalDateTime");
                    }
                }
            }
            template.process(data, writer);
        } catch (IOException | TemplateException e) {
            throw new RuntimeException(e);
        }
    }

    public static String pkgToPath(String pkg) {
        return "src" + File.separator + "test" + File.separator + "java" + File.separator
                + pkg.replace(".", File.separator);
    }
}
