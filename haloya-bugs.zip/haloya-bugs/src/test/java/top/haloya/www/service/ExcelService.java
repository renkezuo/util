package top.haloya.www.service;

import com.alibaba.excel.EasyExcel;
import top.haloya.www.listener.TestBugListener;
import top.haloya.www.model.excel.TestBug;

import java.io.File;

public class ExcelService {

    public static void main(String[] args) {
        String fileName = File.separator+"file"+File.separator+"demo.xlsx";
        // 这里 需要指定读用哪个class去读，然后读取第一个sheet 文件流会自动关闭
        EasyExcel.read(fileName, TestBug.class, new TestBugListener(fileName))
                .sheet().doRead();
    }
}
