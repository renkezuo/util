package top.haloya.www.model.dto;
import lombok.Setter;
import lombok.Getter;

@Setter
@Getter
public class BaidubceIp {
    private String code;
    private Data data;
    private Boolean charge;
    private String msg;
    private String ip;
    private String coordsys;
}