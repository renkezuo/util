package top.haloya.www.util;

import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;

import java.util.concurrent.TimeUnit;

public class CacheUtils {
    private static Cache<String, Object> cache = Caffeine.newBuilder()
            .initialCapacity(1000)
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .build();
    public void put(String key, Object obj){
        cache.put(key, obj);
    }

    public Object get(String key){
        return cache.getIfPresent(key);
    }


    public void increment(String key){
        cache.invalidate(key);
    }
}
