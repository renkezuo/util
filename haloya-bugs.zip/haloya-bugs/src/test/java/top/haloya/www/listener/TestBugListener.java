package top.haloya.www.listener;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.alibaba.excel.util.ListUtils;
import lombok.extern.slf4j.Slf4j;
import top.haloya.base.utils.JsonUtils;
import top.haloya.www.model.excel.TestBug;

import java.util.List;

@Slf4j
public class TestBugListener implements ReadListener<TestBug> {

    /**
     * 每隔5条存储数据库，实际使用中可以100条，然后清理list ，方便内存回收
     */
    private static final int BATCH_COUNT = 100;
    /**
     * 缓存的数据
     */
    private List<TestBug> cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);

    private String fileName;
    public TestBugListener(String fileName) {
        this.fileName = fileName;
    }

    /**
     * 这个每一条数据解析都会来调用
     *
     * @param bug    one row value. Is is same as {@link AnalysisContext#readRowHolder()}
     * @param context
     */
    @Override
    public void invoke(TestBug bug, AnalysisContext context) {
        log.info("解析到一条数据:{}", JsonUtils.toJson(bug));
        // 直接处理data
        // 1. 领域一层、领域二层、领域三层、所属空间、创建人、归属人、创建时间、创建月份、严重程度、是否红线、根因类型、状态、主题、重开次数、拒绝次数、缺陷分类(线上|非线上)、开发解决周期、测试验证周期
        // 领域一层 (fileName)

        cachedDataList.add(bug);
        // 达到BATCH_COUNT了，需要去存储一次数据库，防止数据几万条数据在内存，容易OOM
        if (cachedDataList.size() >= BATCH_COUNT) {
            saveData();
            // 存储完成清理 list
            cachedDataList = ListUtils.newArrayListWithExpectedSize(BATCH_COUNT);
        }
    }

    /**
     * 所有数据解析完成了 都会来调用
     *
     * @param context
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 这里也要保存数据，确保最后遗留的数据也存储到数据库
        saveData();
        log.info("所有数据解析完成！");
    }

    /**
     * 加上存储数据库
     */
    private void saveData() {
        log.info("{}条数据，开始存储数据库！", cachedDataList.size());
        for(TestBug data : cachedDataList) {

            log.info(JsonUtils.toJson(data));
        }
        log.info("存储数据库成功！");
    }
}