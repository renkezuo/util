package top.haloya.www.model.excel;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@EqualsAndHashCode
public class OnlineBug {
    @ExcelProperty("指派给")
    private String currentUser;
    @ExcelProperty("创建人")
    private String createUser;
    @ExcelProperty("创建时间")
    private Date date;
    @ExcelProperty("缺陷归属")
    private String ownerUser;
    @ExcelProperty("测试大哥")
    private String bigBrother;
}